Dear customer, to test your application, please follow this link:
https://tdvjj1ts-7089.euw.devtunnels.ms/swagger/index.html